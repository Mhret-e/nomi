# Nomi backend setup · 0.4.0

The APK contains public client configuration for project `ucnptfdchhslvhqtniwr`. No migration or function has been deployed to this project by this workspace. A public key cannot perform administrative setup. Do not send administrative keys or passwords in chat.

## Database

Back up an existing project before applying migrations. In the Supabase Dashboard SQL editor, run only migrations not already recorded as applied, in this order:

1. `supabase/migrations/202611020001_nomi.sql`
2. `supabase/migrations/202611030001_real_stores_and_leaderboard.sql`
3. `supabase/migrations/202611050001_merchant_staff.sql`
4. `supabase/seed_real_stores.sql`

Do not run `supabase/tests/bootstrap.sql` against a hosted project. The old `seed.sql` is a fictional test fixture. The real directory starts with no voucher partners. Do not enable vouchers until the business agrees.

Enable email/password authentication and anonymous sign-ins in Auth settings. Keep email confirmation enabled; configure production mail delivery and abuse controls before public launch. Confirm an email account before signing in.

## Authenticated functions

From the project source with the Supabase CLI installed, authenticate on your own computer, then:

```sh
supabase login
supabase link --project-ref ucnptfdchhslvhqtniwr
supabase functions deploy delete-account
supabase functions deploy redeem-voucher
```

Deploy the shared `_shared/handlers.mjs` alongside both entrypoints. `supabase/config.toml` disables the gateway's legacy JWT check because each handler independently verifies the bearer token against Supabase Auth `/user`. Never remove that verification. Standard Edge environment variables `SUPABASE_URL`, `SUPABASE_ANON_KEY` and `SUPABASE_SERVICE_ROLE_KEY` stay server-side. Never copy the service-role key into the APK, browser configuration, cashier client or repository.

Deletion derives the account ID from the verified caller, requires exact DELETE confirmation, and requires email users to sign in again within ten minutes. It deletes that auth user and cascades their owned database records. A lost anonymous session cannot authenticate for deletion; provide a real support contact and a verified ownership process. Erasing device history signs out and clears local data but does not delete a cloud account.

## External deletion page

Set the same public project configuration and a real `NOMI_SUPPORT_EMAIL`, then run:

```sh
python scripts/build_account_site.py
```

Host `web/account-deletion/dist/` over HTTPS and configure `NOMI_WEB_ORIGIN` in Edge Function secrets to that exact page origin (scheme and hostname, no path). Support users through the displayed contact. Configure CSP/security headers from the generated `_headers` for your host. Hosting is not performed by the build script. Test the live page and add its URL to Play Console; prepared files alone do not meet the deletion-URL requirement.

## Merchant access

After a signed partnership, an administrator can enable that store's `voucher_enabled` flag and insert the cashier's verified Auth UUID/store UUID into `public.merchant_staff`. Ordinary users cannot self-assign membership. Cashiers run `python scripts/cashier.py STORE_UUID` with public configuration, enter their own email/password and scan/type a voucher. The backend checks membership for that exact active partner store and consumes the code atomically. No real-value voucher flow has been validated with a partner.

## Live verification still required

Test two separate accounts: each sees only its own records; repeated break UUIDs do not duplicate points; customer accounts cannot redeem or enroll as staff; the wrong-store cashier cannot redeem; a redeemed code cannot be reused. Use disposable accounts to test deletion and cross-account isolation. Verify anonymous session recovery expectations and the external deletion page. Never delete a real account to perform a smoke test.

The current environment blocks the project hostname. Its allowlist needs `ucnptfdchhslvhqtniwr.supabase.co` before this workspace can perform live checks. Business/photo research also remains blocked, so venue photos and current listings are unverified. No environment changes are published by these instructions.
