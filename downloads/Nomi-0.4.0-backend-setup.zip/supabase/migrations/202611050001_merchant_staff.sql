begin;
create table public.merchant_staff (
 user_id uuid not null references auth.users(id) on delete cascade,
 store_id uuid not null references public.stores(id) on delete cascade,
 active boolean not null default true,
 created_at timestamptz not null default now(),
 primary key(user_id,store_id)
);
alter table public.merchant_staff enable row level security;
create policy merchant_own_memberships on public.merchant_staff for select to authenticated using(user_id=auth.uid());
revoke all on public.merchant_staff from public,anon,authenticated;
grant select on public.merchant_staff to authenticated;
grant select,insert,update,delete on public.merchant_staff to service_role;
-- No customer INSERT/UPDATE policies. Provision staff through a trusted project administrator only.
commit;
