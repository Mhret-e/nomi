begin;
-- A real-business listing is not a commercial agreement. Only an administrator can enable vouchers.
alter table public.stores add column if not exists voucher_enabled boolean not null default false;
alter table public.vouchers drop constraint if exists vouchers_status_check;
alter table public.vouchers add constraint vouchers_status_check check(status in ('issued','redeemed','void'));
update public.vouchers v set status='void' from public.stores s where v.store_id=s.id and not s.voucher_enabled and v.status='issued';

create or replace function public.leaderboard_today_v2()
returns table("position" bigint,display_name text,points bigint,is_you boolean)
language sql stable security definer set search_path='' as $$
 select row_number() over(order by sum(l.points) desc,p.id),p.display_name,sum(l.points),p.id=auth.uid()
 from public.points_ledger l join public.profiles p on p.id=l.user_id
 where auth.uid() is not null
   and l.created_at >= date_trunc('day',now() at time zone 'UTC') at time zone 'UTC'
   and l.created_at < (date_trunc('day',now() at time zone 'UTC')+interval '1 day') at time zone 'UTC'
 group by p.id,p.display_name order by sum(l.points) desc,p.id limit 50
$$;
revoke all on function public.leaderboard_today_v2() from public,anon,authenticated;
grant execute on function public.leaderboard_today_v2() to authenticated;

create or replace function public.issue_voucher(p_store_id uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare total bigint; discount integer; issued public.vouchers; reward_day date := (now() at time zone 'UTC')::date;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,0));
 if not exists(select 1 from public.stores where id=p_store_id and active and voucher_enabled) then raise exception 'This store does not have an active Nomi voucher agreement'; end if;
 select * into issued from public.vouchers where user_id=auth.uid() and reward_date=reward_day;
 if found then
   if issued.store_id<>p_store_id then raise exception 'Today’s voucher is already assigned to another store'; end if;
   if issued.status<>'issued' then raise exception 'Today’s voucher is unavailable or already used'; end if;
   return jsonb_build_object('code',issued.code,'percent',issued.percent);
 end if;
 select coalesce(sum(points),0) into total from public.points_ledger where user_id=auth.uid() and (created_at at time zone 'UTC')::date=reward_day;
 discount:=case when total>=200 then 10 when total>=150 then 5 else 0 end;
 if discount=0 then raise exception 'Reach 150 points to unlock 5%% off'; end if;
 insert into public.vouchers(user_id,store_id,code,percent,reward_date)
 values(auth.uid(),p_store_id,upper(encode(extensions.gen_random_bytes(16),'hex')),discount,reward_day) returning * into issued;
 return jsonb_build_object('code',issued.code,'percent',issued.percent);
end $$;
revoke all on function public.issue_voucher(uuid) from public,anon,authenticated;
grant execute on function public.issue_voucher(uuid) to authenticated;
commit;
