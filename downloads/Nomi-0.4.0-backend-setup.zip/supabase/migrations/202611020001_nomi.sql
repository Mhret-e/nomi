-- Non-sensitive data only. Notification and app usage entities have NO cloud tables.
create extension if not exists pgcrypto with schema extensions;
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Nomi friend' check (length(display_name) between 1 and 40)
);
create table public.breaks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  type text not null check (type in ('WALK','READ','JOURNAL','OTHER','REST')),
  completed_at timestamptz not null default now()
);
create table public.points_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  break_id uuid not null unique references public.breaks(id) on delete cascade,
  points integer not null check (points between 1 and 25),
  reason text not null check (reason in ('WALK','READ','JOURNAL','OTHER','REST')),
  created_at timestamptz not null default now()
);
create table public.daily_stats (
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  date date not null,
  scroll_minutes integer not null default 0 check (scroll_minutes >= 0),
  breaks_completed integer not null default 0 check (breaks_completed >= 0),
  automatic_opens_caught integer not null default 0 check (automatic_opens_caught >= 0),
  filtered_count integer not null default 0 check (filtered_count >= 0),
  primary key (user_id,date)
);
create table public.stores (
  id uuid primary key default gen_random_uuid(), name text not null,
  category text not null check (category in ('Food & drink','Local favorites')),
  tagline text not null, image_url text not null default '', active boolean not null default true
);
create table public.vouchers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  store_id uuid not null references public.stores(id),
  code text not null unique,
  percent integer not null check (percent in (5,10)),
  status text not null default 'issued' check (status in ('issued','redeemed')),
  reward_date date not null,
  created_at timestamptz not null default now(), redeemed_at timestamptz,
  unique(user_id,reward_date)
);
create index on public.points_ledger(user_id,created_at);
create index on public.breaks(user_id,completed_at);
alter table public.profiles enable row level security;
alter table public.breaks enable row level security;
alter table public.points_ledger enable row level security;
alter table public.daily_stats enable row level security;
alter table public.stores enable row level security;
alter table public.vouchers enable row level security;
create policy profiles_own on public.profiles for all to authenticated using (id=auth.uid()) with check (id=auth.uid());
create policy breaks_own_read on public.breaks for select to authenticated using (user_id=auth.uid());
create policy ledger_own_read on public.points_ledger for select to authenticated using (user_id=auth.uid());
create policy stats_own on public.daily_stats for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy stores_active_read on public.stores for select to authenticated using (active);
create policy vouchers_own_read on public.vouchers for select to authenticated using (user_id=auth.uid());
-- Rewards can only be written through the guarded functions below.
revoke all on public.breaks,public.points_ledger,public.vouchers,public.stores from anon,authenticated;
grant select on public.breaks,public.points_ledger,public.vouchers,public.stores to authenticated;
grant select,insert,update,delete on public.profiles,public.daily_stats to authenticated;

create function public.on_nomi_user() returns trigger language plpgsql security definer set search_path='' as $$
begin
  insert into public.profiles(id) values(new.id);
  return new;
end $$;
create trigger nomi_new_user after insert on auth.users for each row execute function public.on_nomi_user();

-- Idempotent offline sync: retrying a UUID cannot award points twice.
-- Completion is self-reported, NOT proof for financial-grade rewards. See README.
create function public.record_break(p_id uuid,p_type text,p_completed_at timestamptz)
returns void language plpgsql security definer set search_path='' as $$
declare award integer;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_completed_at > now()+interval '5 minutes' or p_completed_at < now()-interval '30 days' then raise exception 'Completion outside sync window'; end if;
  award := case p_type when 'WALK' then 25 when 'READ' then 15 when 'JOURNAL' then 10 when 'OTHER' then 10 when 'REST' then 15 else null end;
  if award is null then raise exception 'Unknown break'; end if;
  perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,0));
  if exists(select 1 from public.breaks where id=p_id) then
    if not exists(select 1 from public.breaks where id=p_id and user_id=auth.uid() and type=p_type and completed_at=p_completed_at) then raise exception 'Conflicting break'; end if;
    return;
  end if;
  if (select coalesce(sum(points),0) from public.points_ledger where user_id=auth.uid() and (created_at at time zone 'UTC')::date=(p_completed_at at time zone 'UTC')::date) + award > 400 then raise exception 'Daily reward limit reached'; end if;
  insert into public.breaks(id,user_id,type,completed_at) values(p_id,auth.uid(),p_type,p_completed_at);
  insert into public.points_ledger(user_id,break_id,points,reason,created_at) values(auth.uid(),p_id,award,p_type,p_completed_at);
end $$;

create function public.today_leaderboard()
returns table(display_name text,points bigint) language sql stable security definer set search_path='' as $$
  select p.display_name,sum(l.points) as points
  from public.points_ledger l join public.profiles p on p.id=l.user_id
  where auth.uid() is not null and l.created_at >= date_trunc('day',now() at time zone 'UTC') at time zone 'UTC'
    and l.created_at < (date_trunc('day',now() at time zone 'UTC')+interval '1 day') at time zone 'UTC'
  group by p.id,p.display_name order by points desc,p.id limit 50
$$;

create function public.issue_voucher(p_store_id uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare total bigint; discount integer; issued public.vouchers; reward_day date := (now() at time zone 'UTC')::date;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,0));
  select * into issued from public.vouchers where user_id=auth.uid() and reward_date=reward_day;
  if found then
    if issued.store_id <> p_store_id then raise exception 'Today’s voucher is already assigned to another store'; end if;
    if issued.status <> 'issued' then raise exception 'Today’s voucher has already been used'; end if;
    return jsonb_build_object('code',issued.code,'percent',issued.percent);
  end if;
  if not exists(select 1 from public.stores where id=p_store_id and active) then raise exception 'Store unavailable'; end if;
  select coalesce(sum(points),0) into total from public.points_ledger where user_id=auth.uid() and (created_at at time zone 'UTC')::date=reward_day;
  discount := case when total>=200 then 10 when total>=150 then 5 else 0 end;
  if discount=0 then raise exception 'Reach 150 points to unlock 5%% off'; end if;
  insert into public.vouchers(user_id,store_id,code,percent,reward_date)
    values(auth.uid(),p_store_id,upper(encode(extensions.gen_random_bytes(16),'hex')),discount,reward_day) returning * into issued;
  return jsonb_build_object('code',issued.code,'percent',issued.percent);
end $$;

-- TRUSTED CASHIER BACKEND ONLY. Never ship a service_role key in the Android app.
-- Row lock makes concurrent redemption attempts atomic; second use fails.
create function public.redeem_voucher(p_code text,p_store_id uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare v public.vouchers;
begin
  select * into v from public.vouchers where code=upper(p_code) and store_id=p_store_id for update;
  if not found or v.status <> 'issued' then raise exception 'Invalid or already used voucher'; end if;
  update public.vouchers set status='redeemed',redeemed_at=now() where id=v.id;
  return jsonb_build_object('valid',true,'percent',v.percent);
end $$;
revoke all on function public.on_nomi_user() from public,anon,authenticated;
revoke all on function public.record_break(uuid,text,timestamptz),public.today_leaderboard(),public.issue_voucher(uuid),public.redeem_voucher(text,uuid) from public,anon,authenticated;
grant execute on function public.record_break(uuid,text,timestamptz),public.today_leaderboard(),public.issue_voucher(uuid) to authenticated;
grant execute on function public.redeem_voucher(text,uuid) to service_role;

insert into storage.buckets(id,name,public) values('store-images','store-images',true) on conflict(id) do nothing;
create policy store_photos_public_read on storage.objects for select using(bucket_id='store-images');
-- No client upload/update/delete policies. Upload store photos using the Dashboard or a trusted admin.
