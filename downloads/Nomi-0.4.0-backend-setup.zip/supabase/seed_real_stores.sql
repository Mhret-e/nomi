-- Initial directory facts supplied by the user in restaurant-listing screenshots, 3 November 2026.
-- No claim of current ratings/prices/hours, verified photo rights, or a Nomi commercial agreement.
-- Disable only the unchanged original fictional prototype fixtures; never reuse their IDs for real businesses.
update public.stores set active=false where id in (
'00000000-0000-4000-8000-000000000001','00000000-0000-4000-8000-000000000002','00000000-0000-4000-8000-000000000003',
'00000000-0000-4000-8000-000000000004','00000000-0000-4000-8000-000000000005','00000000-0000-4000-8000-000000000006')
and name in ('Café Lumen','Olive & Thyme','Green Bowl','FitHub Gym','Pageturn Books','Sable Store');
insert into public.stores(id,name,category,tagline,image_url,active,voucher_enabled) values
('30000000-0000-4000-8000-000000000001','Puranmal','Food & drink','Indian vegetarian food · Al Nahda, Sharjah','',true,false),
('30000000-0000-4000-8000-000000000002','Kamat','Food & drink','Indian vegetarian food · Al Qusais, Dubai','',true,false),
('30000000-0000-4000-8000-000000000003','71 Steak & Grill','Food & drink','Steakhouse · City Centre Al Zahia, Sharjah','',true,false),
('30000000-0000-4000-8000-000000000004','Parker’s','Food & drink','Restaurant and desserts · City Centre Mirdif, Dubai','',true,false),
('30000000-0000-4000-8000-000000000005','Murmur','Food & drink','Fusion dining · Aljada, Sharjah','',true,false),
('30000000-0000-4000-8000-000000000006','The Copper Table Bistro','Food & drink','Italian dining · City Centre Al Zahia, Sharjah','',true,false)
on conflict(id) do update set name=excluded.name,category=excluded.category,tagline=excluded.tagline;
