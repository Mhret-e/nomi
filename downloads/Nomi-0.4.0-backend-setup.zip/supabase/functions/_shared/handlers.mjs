/** Dependency-free Edge handlers. Tokens, voucher codes and response bodies are never logged. */
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const maxBody = 8192;

export function createHandlers({ env, fetcher = fetch, now = () => Date.now() }) {
  function reply(status, payload, origin) {
    const headers = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };
    if (origin) { headers['Access-Control-Allow-Origin'] = origin; headers.Vary = 'Origin'; }
    return new Response(payload === null ? null : JSON.stringify(payload), { status, headers });
  }
  async function authenticate(request) {
    const origin = request.headers.get('origin');
    const allowedOrigin = env('NOMI_WEB_ORIGIN');
    if (origin && (!allowedOrigin || origin !== allowedOrigin)) return { error: reply(403, { error: 'origin_not_allowed' }) };
    if (request.method === 'OPTIONS') {
      if (!origin) return { error: reply(400, { error: 'missing_origin' }) };
      return { error: new Response(null, { status: 204, headers: {
        'Access-Control-Allow-Origin': origin, Vary: 'Origin',
        'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
        'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Cache-Control': 'no-store',
      } }) };
    }
    if (request.method !== 'POST') return { error: reply(405, { error: 'post_required' }, origin) };
    const url = env('SUPABASE_URL');
    const anon = env('SUPABASE_ANON_KEY');
    const service = env('SUPABASE_SERVICE_ROLE_KEY');
    if (!url?.startsWith('https://') || !anon || !service) return { error: reply(503, { error: 'server_not_configured' }, origin) };
    const base = new URL(url);
    if (base.username || base.password || base.search || base.hash || !['', '/'].includes(base.pathname)) return { error: reply(503, { error: 'server_not_configured' }, origin) };
    const auth = request.headers.get('authorization');
    if (!auth || !/^Bearer \S+$/i.test(auth)) return { error: reply(401, { error: 'sign_in_required' }, origin) };
    const response = await fetcher(`${base.origin}/auth/v1/user`, { headers: { apikey: anon, Authorization: auth }, signal: AbortSignal.timeout(10000) });
    if (!response.ok) return { error: reply(response.status >= 500 ? 503 : 401, { error: response.status >= 500 ? 'auth_unavailable' : 'sign_in_required' }, origin) };
    const user = await response.json();
    if (typeof user.id !== 'string' || !uuid.test(user.id)) return { error: reply(401, { error: 'sign_in_required' }, origin) };
    return { base: base.origin, anon, service, auth, user, origin };
  }
  async function body(request) {
    if (!request.headers.get('content-type')?.toLowerCase().startsWith('application/json')) throw new Error('bad_body');
    const reader = request.body?.getReader();
    if (!reader) throw new Error('bad_body');
    let length = 0; const chunks = [];
    try {
      while (true) {
        const item = await reader.read();
        if (item.done) break;
        length += item.value.length;
        if (length > maxBody) { await reader.cancel(); throw new Error('bad_body'); }
        chunks.push(item.value);
      }
    } finally { reader.releaseLock(); }
    const bytes = new Uint8Array(length); let offset = 0;
    for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
    const value = JSON.parse(new TextDecoder().decode(bytes));
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('bad_body');
    return value;
  }
  async function deleteAccount(request) {
    let origin;
    try {
      const ctx = await authenticate(request);
      if (ctx.error) return ctx.error;
      origin = ctx.origin;
      let input;
      try { input = await body(request); } catch { return reply(400, { error: 'invalid_confirmation' }, origin); }
      if (input.confirmation !== 'DELETE' || Object.keys(input).some(key => key !== 'confirmation')) return reply(400, { error: 'invalid_confirmation' }, origin);
      // Refreshing a token is not a substitute for recent sign-in on an email account.
      const signedAt = Date.parse(ctx.user.last_sign_in_at);
      const age = now() - signedAt;
      if (ctx.user.is_anonymous !== true && (!Number.isFinite(signedAt) || age < -60000 || age > 10 * 60 * 1000)) return reply(403, { error: 'recent_sign_in_required' }, origin);
      const response = await fetcher(`${ctx.base}/auth/v1/admin/users/${ctx.user.id}`, {
        method: 'DELETE', headers: { apikey: ctx.service, Authorization: `Bearer ${ctx.service}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ should_soft_delete: false }), signal: AbortSignal.timeout(10000),
      });
      if (!response.ok) return reply(503, { error: 'deletion_not_confirmed' }, origin);
      // auth.users deletion cascades only this user's profiles/rewards/stats/vouchers through migration FKs.
      return reply(200, { deleted: true }, origin);
    } catch { return reply(503, { error: 'deletion_not_confirmed' }, origin); }
  }
  async function redeemVoucher(request) {
    let origin;
    try {
      const ctx = await authenticate(request);
      if (ctx.error) return ctx.error;
      origin = ctx.origin;
      let input;
      try { input = await body(request); } catch { return reply(400, { error: 'invalid_request' }, origin); }
      if (Object.keys(input).some(key => !['store_id', 'code'].includes(key)) || !uuid.test(input.store_id ?? '') || typeof input.code !== 'string' || !/^[0-9a-f]{32}$/i.test(input.code.trim())) return reply(400, { error: 'invalid_request' }, origin);
      if (ctx.user.is_anonymous === true) return reply(403, { error: 'merchant_access_required' }, origin);
      const store = input.store_id.toLowerCase();
      const headers = { apikey: ctx.anon, Authorization: ctx.auth };
      const staff = await fetcher(`${ctx.base}/rest/v1/merchant_staff?select=store_id&user_id=eq.${ctx.user.id}&store_id=eq.${store}&active=eq.true`, { headers, signal: AbortSignal.timeout(10000) });
      if (!staff.ok) return reply(503, { error: 'merchant_check_unavailable' }, origin);
      const memberships = await staff.json();
      if (!Array.isArray(memberships) || !memberships.some(row => row.store_id === store)) return reply(403, { error: 'merchant_access_required' }, origin);
      const activeStore = await fetcher(`${ctx.base}/rest/v1/stores?select=id&id=eq.${store}&active=eq.true&voucher_enabled=eq.true`, { headers, signal: AbortSignal.timeout(10000) });
      if (!activeStore.ok) return reply(503, { error: 'merchant_check_unavailable' }, origin);
      const stores = await activeStore.json();
      if (!Array.isArray(stores) || !stores.some(row => row.id === store)) return reply(403, { error: 'store_not_participating' }, origin);
      const result = await fetcher(`${ctx.base}/rest/v1/rpc/redeem_voucher`, {
        method: 'POST', headers: { apikey: ctx.service, Authorization: `Bearer ${ctx.service}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ p_code: input.code.trim().toUpperCase(), p_store_id: store }), signal: AbortSignal.timeout(10000),
      });
      if (!result.ok) return reply(result.status >= 500 ? 503 : 422, { error: result.status >= 500 ? 'redemption_unavailable' : 'invalid_or_used_voucher' }, origin);
      const value = await result.json();
      if (value.valid !== true || ![5, 10].includes(value.percent)) return reply(503, { error: 'redemption_not_confirmed' }, origin);
      return reply(200, { valid: true, percent: value.percent }, origin);
    } catch { return reply(503, { error: 'redemption_unavailable' }, origin); }
  }
  return { deleteAccount, redeemVoucher };
}
