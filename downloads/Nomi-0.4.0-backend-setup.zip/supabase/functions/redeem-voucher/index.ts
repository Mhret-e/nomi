import { createHandlers } from '../_shared/handlers.mjs';
Deno.serve(createHandlers({ env: (name: string) => Deno.env.get(name) }).redeemVoucher);
