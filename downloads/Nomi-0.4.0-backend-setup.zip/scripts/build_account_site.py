#!/usr/bin/env python3
"""Build a static deletion page with public configuration only; does not publish anything."""
import json
import os
from pathlib import Path
import re
import shutil
from urllib.parse import urlsplit

root=Path(__file__).resolve().parents[1]
url=os.environ.get('SUPABASE_URL','').rstrip('/')
key=os.environ.get('SUPABASE_PUBLISHABLE_KEY','')
email=os.environ.get('NOMI_SUPPORT_EMAIL','')
p=urlsplit(url)
if p.scheme!='https' or not p.hostname or p.username or p.password or p.path or p.query or p.fragment:
    raise SystemExit('Set SUPABASE_URL to the HTTPS project origin')
if not key.startswith('sb_publishable_'):
    raise SystemExit('Use a public publishable key, never an administrative secret')
if email and not re.fullmatch(r'[A-Za-z0-9.!#$%&\x27*+/=?^_`{|}~-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',email):
    raise SystemExit('Use a valid Nomi support email')
source=root/'web/account-deletion'; target=source/'dist'
target.mkdir(exist_ok=True)
for name in ['index.html','style.css','page.mjs','client.mjs']:
    shutil.copyfile(source/name,target/name)
shutil.copyfile(root/'app/src/main/res/drawable-nodpi/nomi_mascot.png',target/'nomi.png')
(target/'config.json').write_text(json.dumps({'url':url,'publicKey':key,'supportEmail':email}))
index=(target/'index.html').read_text()
csp=f"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self' {url}; object-src 'none'; base-uri 'none'; form-action 'none'"
index=index.replace('<meta name="referrer"',f'<meta http-equiv="Content-Security-Policy" content="{csp}"><meta name="referrer"')
(target/'index.html').write_text(index)
(target/'_headers').write_text('/*\n  Content-Security-Policy: '+csp+"; frame-ancestors 'none'\n  Referrer-Policy: no-referrer\n  X-Content-Type-Options: nosniff\n")
print('Built deletion site:',target)
if not email: print('Support email is not configured; anonymous/lost-access support is not release-ready.')
