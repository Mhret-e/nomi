#!/usr/bin/env python3
"""Cashier client: normal staff login + public key only. Never uses service-role credentials."""
import argparse
import getpass
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request


def main():
    parser = argparse.ArgumentParser(description="Check and consume one Nomi voucher for your approved store")
    parser.add_argument("store_id")
    args = parser.parse_args()
    if not re.fullmatch(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", args.store_id):
        raise SystemExit("A valid store UUID is required")
    url = os.environ.get("SUPABASE_URL", "").rstrip("/")
    parts = urllib.parse.urlsplit(url)
    if parts.scheme != "https" or not parts.hostname or parts.username or parts.password or parts.query or parts.fragment or parts.path:
        raise SystemExit("Set SUPABASE_URL to your HTTPS project origin")
    key = os.environ.get("SUPABASE_PUBLISHABLE_KEY")
    if not key:
        raise SystemExit("Set the public SUPABASE_PUBLISHABLE_KEY; a service-role key must never be used here")
    email = input("Staff email: ").strip()
    password = getpass.getpass("Staff password: ")

    def post(path, payload, token=None):
        headers = {"apikey": key, "Content-Type": "application/json"}
        if token:
            headers["Authorization"] = "Bearer " + token
        request = urllib.request.Request(url + path, data=json.dumps(payload).encode(), headers=headers, method="POST")
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.load(response)

    try:
        session = post("/auth/v1/token?grant_type=password", {"email": email, "password": password})
    except (urllib.error.HTTPError, urllib.error.URLError):
        raise SystemExit("Sign-in failed. Check the project configuration and your staff account.")
    password = None
    token = session.get("access_token")
    if not isinstance(token, str) or not token:
        raise SystemExit("Sign-in did not return a session; do not apply a discount")
    code = input("One-time voucher code: ").strip().upper()
    if not re.fullmatch(r"[0-9A-F]{32}", code):
        raise SystemExit("Invalid code format; do not apply a discount")
    try:
        result = post("/functions/v1/redeem-voucher", {"store_id": args.store_id.lower(), "code": code}, token)
    except (urllib.error.HTTPError, urllib.error.URLError):
        raise SystemExit("Redemption was not confirmed. Do not apply a discount; check staff access, store eligibility and whether the code was already used.")
    if result.get("valid") is not True or result.get("percent") not in (5, 10):
        raise SystemExit("Redemption was not confirmed; do not apply a discount")
    print(f"Redeemed once: apply {result['percent']}% discount.")


if __name__ == "__main__":
    main()
